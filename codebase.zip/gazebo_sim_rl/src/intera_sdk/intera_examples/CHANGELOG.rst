5.0.3 (2016-12-05)
---------------------------------
- Initial release of interai_examples, borrowing heavily from baxter_examples
  but robot-agnostic to any robot running Intera

