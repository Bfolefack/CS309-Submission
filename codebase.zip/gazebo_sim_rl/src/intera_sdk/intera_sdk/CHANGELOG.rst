5.0.3 (2016-12-05)
---------------------------------
- Initial release of intera_sdk, borrowing heavily from baxter_sdk
  but robot-agnostic to any robot running Intera
