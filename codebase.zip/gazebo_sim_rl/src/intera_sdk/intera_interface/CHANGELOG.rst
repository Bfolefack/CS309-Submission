5.0.3 (2016-12-05)
---------------------------------
- Initial release of intera_interface, borrowing heavily from baxter_interface
  but robot-agnostic to any robot running Intera
